
<div class="form-floating mb-3 rounded-top">
    {{$slot}}

    <x-form.error name="{{$name}}" />
</div>
