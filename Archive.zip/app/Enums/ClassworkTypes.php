<?php

namespace App\Enums;
enum ClassworkTypes : string {

    case ASSIGNMENT ='assignment';
    case MATERIAL ='material';
    case QUESTION ='question';

}
